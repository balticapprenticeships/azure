@{
    # Script module or binary module file associated with this manifest.
    RootModule           = 'SqlServerDsc.psm1'

    # Version number of this module.
    ModuleVersion        = '17.3.0'

    # ID used to uniquely identify this module
    GUID                 = '693ee082-ed36-45a7-b490-88b07c86b42f'

    # Author of this module
    Author               = 'DSC Community'

    # Company or vendor of this module
    CompanyName          = 'DSC Community'

    # Copyright statement for this module
    Copyright            = 'Copyright the DSC Community contributors. All rights reserved.'

    # Description of the functionality provided by this module
    Description          = 'This module contains commands and DSC resources for deployment and configuration of Microsoft SQL Server, SQL Server Reporting Services and Power BI Report Server.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion    = '5.0'

    # Minimum version of the common language runtime (CLR) required by this module
    CLRVersion           = '4.0'

    # Functions to export from this module
    FunctionsToExport    = @('Add-SqlDscFileGroup','Add-SqlDscNode','Add-SqlDscTraceFlag','Assert-SqlDscAgentOperator','Assert-SqlDscLogin','Complete-SqlDscFailoverCluster','Complete-SqlDscImage','Connect-SqlDscDatabaseEngine','ConvertFrom-SqlDscDatabasePermission','ConvertFrom-SqlDscServerPermission','ConvertTo-SqlDscDatabasePermission','ConvertTo-SqlDscDataFile','ConvertTo-SqlDscEditionName','ConvertTo-SqlDscFileGroup','ConvertTo-SqlDscServerPermission','Deny-SqlDscServerPermission','Disable-SqlDscAgentOperator','Disable-SqlDscAudit','Disable-SqlDscDatabaseSnapshotIsolation','Disable-SqlDscLogin','Disconnect-SqlDscDatabaseEngine','Enable-SqlDscAgentOperator','Enable-SqlDscAudit','Enable-SqlDscDatabaseSnapshotIsolation','Enable-SqlDscLogin','Get-SqlDscAgentAlert','Get-SqlDscAgentOperator','Get-SqlDscAudit','Get-SqlDscCompatibilityLevel','Get-SqlDscConfigurationOption','Get-SqlDscDatabase','Get-SqlDscDatabasePermission','Get-SqlDscInstalledInstance','Get-SqlDscLogin','Get-SqlDscManagedComputer','Get-SqlDscManagedComputerInstance','Get-SqlDscManagedComputerService','Get-SqlDscPreferredModule','Get-SqlDscRole','Get-SqlDscRSSetupConfiguration','Get-SqlDscServerPermission','Get-SqlDscServerProtocol','Get-SqlDscServerProtocolName','Get-SqlDscSetupLog','Get-SqlDscStartupParameter','Get-SqlDscTraceFlag','Grant-SqlDscServerPermission','Import-SqlDscPreferredModule','Initialize-SqlDscRebuildDatabase','Install-SqlDscBIReportServer','Install-SqlDscReportingService','Install-SqlDscServer','Invoke-SqlDscQuery','New-SqlDscAgentAlert','New-SqlDscAgentOperator','New-SqlDscAudit','New-SqlDscDatabase','New-SqlDscDatabaseSnapshot','New-SqlDscDataFile','New-SqlDscFileGroup','New-SqlDscLogin','New-SqlDscRole','Remove-SqlDscAgentAlert','Remove-SqlDscAgentOperator','Remove-SqlDscAudit','Remove-SqlDscDatabase','Remove-SqlDscLogin','Remove-SqlDscNode','Remove-SqlDscRole','Remove-SqlDscTraceFlag','Repair-SqlDscBIReportServer','Repair-SqlDscReportingService','Repair-SqlDscServer','Revoke-SqlDscServerPermission','Save-SqlDscSqlServerMediaFile','Set-SqlDscAgentAlert','Set-SqlDscAgentOperator','Set-SqlDscAudit','Set-SqlDscConfigurationOption','Set-SqlDscDatabaseDefault','Set-SqlDscDatabaseOwner','Set-SqlDscDatabasePermission','Set-SqlDscDatabaseProperty','Set-SqlDscServerPermission','Set-SqlDscStartupParameter','Set-SqlDscTraceFlag','Test-SqlDscAgentAlertProperty','Test-SqlDscConfigurationOption','Test-SqlDscDatabaseProperty','Test-SqlDscIsAgentAlert','Test-SqlDscIsAgentOperator','Test-SqlDscIsDatabase','Test-SqlDscIsDatabasePrincipal','Test-SqlDscIsLogin','Test-SqlDscIsLoginEnabled','Test-SqlDscIsRole','Test-SqlDscIsSupportedFeature','Test-SqlDscRSInstalled','Test-SqlDscServerPermission','Uninstall-SqlDscBIReportServer','Uninstall-SqlDscReportingService','Uninstall-SqlDscServer')

    # Cmdlets to export from this module
    # Use wildcard to avoid PSDesiredStateConfiguration 2.0.7 filtering class-based DSC resources (see #2109).
    CmdletsToExport      = '*'

    # Variables to export from this module
    VariablesToExport    = @()

    # Aliases to export from this module
    AliasesToExport      = 'Test-SqlDscAgentAlert'

    DscResourcesToExport = @('SqlAgentAlert','SqlAudit','SqlDatabasePermission','SqlPermission','SqlRSSetup','SqlAG','SqlAGDatabase','SqlAgentFailsafe','SqlAgentOperator','SqlAGListener','SqlAGReplica','SqlAlias','SqlAlwaysOnService','SqlConfiguration','SqlDatabase','SqlDatabaseDefaultLocation','SqlDatabaseMail','SqlDatabaseObjectPermission','SqlDatabaseRole','SqlDatabaseUser','SqlEndpoint','SqlEndpointPermission','SqlLogin','SqlMaxDop','SqlMemory','SqlProtocol','SqlProtocolTcpIp','SqlReplication','SqlRole','SqlRS','SqlScript','SqlScriptQuery','SqlSecureConnection','SqlServiceAccount','SqlSetup','SqlTraceFlag','SqlWaitForAG','SqlWindowsFirewall')

    RequiredAssemblies   = @()

    # Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    PrivateData          = @{

        PSData = @{
            # Set to a prerelease string value if the release should be a prerelease.
            Prerelease   = ''

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource', 'SqlServer', 'PowerBI', 'ReportingServices', 'ReportServer')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/dsccommunity/SqlServerDsc/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/dsccommunity/SqlServerDsc'

            # A URL to an icon representing this module.
            IconUri      = 'https://dsccommunity.org/images/DSC_Logo_300p.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [17.3.0] - 2025-11-30

### Removed

- BREAKING CHANGE: Removed public command `Test-SqlDscDatabase`. Use
  `Test-SqlDscIsDatabase` to check existence. For property checks, use
  `Test-SqlDscDatabaseProperty`. See [issue #2201](https://github.com/dsccommunity/SqlServerDsc/issues/2201).
- BREAKING CHANGE: `Set-SqlDscDatabase`
  - Removed parameter `OwnerName` [issue #2177](https://github.com/dsccommunity/SqlServerDsc/issues/2177).
    Use the new command `Set-SqlDscDatabaseOwner` to change database ownership instead.
- BREAKING CHANGE: `Set-SqlDscDatabaseProperty`
  - Removed parameters `AzureEdition` and `AzureServiceObjective`. Azure SQL Database
    service tier and SLO changes should be managed using `Set-AzSqlDatabase` from the
    Azure PowerShell module instead. See [issue #2177](https://github.com/dsccommunity/SqlServerDsc/issues/2177).
  - Removed parameter `DatabaseSnapshotBaseName`. Database snapshots should be
    created using the `New-SqlDscDatabaseSnapshot`, or the `New-SqlDscDatabase`
    command with the `-DatabaseSnapshotBaseName` parameter.
  - Removed parameter `DefaultSchema`. Default schema is a user-level property,
    not a database-level property. See [issue #2177](https://github.com/dsccommunity/SqlServerDsc/issues/2177).
  - Removed parameter `IsLedger`. Ledger status is read-only after database creation.
    Use `New-SqlDscDatabase` with the `-IsLedger` parameter to create ledger databases
    [issue #2351](https://github.com/dsccommunity/SqlServerDsc/issues/2351).

### Added

- Added public command `Enable-SqlDscDatabaseSnapshotIsolation` to enable snapshot
  isolation for a database in a SQL Server Database Engine instance. This command
  uses the SMO `SetSnapshotIsolation()` method to enable row-versioning and snapshot
  isolation settings to optimize concurrency and consistency ([issue #2329](https://github.com/dsccommunity/SqlServerDsc/issues/2329)).
- Added public command `Disable-SqlDscDatabaseSnapshotIsolation` to disable snapshot
  isolation for a database in a SQL Server Database Engine instance. This command
  uses the SMO `SetSnapshotIsolation()` method to disable row-versioning and snapshot
  isolation settings ([issue #2329](https://github.com/dsccommunity/SqlServerDsc/issues/2329)).
- Added public command `New-SqlDscDatabaseSnapshot` to create database snapshots
  in a SQL Server Database Engine instance using SMO. This command provides an
  automated and DSC-friendly approach to snapshot management by leveraging
  `New-SqlDscDatabase` for the actual creation. The command now supports `FileGroup`
  and `DataFile` parameters to allow control over snapshot file placement and
  structure ([issue #2341](https://github.com/dsccommunity/SqlServerDsc/issues/2341)).
- Added public command `New-SqlDscFileGroup` to create FileGroup objects for SQL
  Server databases. This command simplifies creating FileGroup objects that can be
  used with `New-SqlDscDatabase` and other database-related commands. The `Database`
  parameter is optional, allowing FileGroup objects to be created standalone and
  added to a Database later using `Add-SqlDscFileGroup`.
- Added public command `New-SqlDscDataFile` to create DataFile objects for SQL
  Server FileGroups. This command simplifies creating DataFile objects with
  specified physical file paths, supporting both regular database files (.mdf, .ndf)
  and sparse files for database snapshots (.ss). The `FileGroup` parameter is
  mandatory, requiring DataFile objects to be created with an associated FileGroup.
- Added public command `Add-SqlDscFileGroup` to add one or more FileGroup objects
  to a Database. This command provides a clean way to associate FileGroup objects
  with a Database after they have been created.
- Added public command `ConvertTo-SqlDscDataFile` to convert `DatabaseFileSpec`
  objects to SMO DataFile objects.
- Added public command `ConvertTo-SqlDscFileGroup` to convert `DatabaseFileGroupSpec`
  objects to SMO FileGroup objects.
- Added class `DatabaseFileSpec` to define data file specifications without requiring
  a database or SMO context.
- Added class `DatabaseFileGroupSpec` to define file group specifications with
  associated data files without requiring a database or SMO context.
- `New-SqlDscDatabase`
  - Added `FileGroup` and `DataFile` parameters to allow specifying custom file
    locations and structure. These parameters apply to both regular databases and
    database snapshots, enabling control over file placement for snapshots (sparse
    files) and custom filegroup/datafile configuration for regular databases
    ([issue #2341](https://github.com/dsccommunity/SqlServerDsc/issues/2341)).
  - Added `IsLedger` parameter to support creating ledger databases at creation time.
    Ledger status is read-only after database creation and can only be set when
    creating a new database ([issue #2351](https://github.com/dsccommunity/SqlServerDsc/issues/2351)).
- Added public command `Set-SqlDscDatabaseOwner` to change the owner of a SQL Server
  database [issue #2177](https://github.com/dsccommunity/SqlServerDsc/issues/2177).
  This command uses the SMO `SetOwner()` method and supports both `ServerObject`
  and `DatabaseObject` parameter sets. This replaces the ownership changes
  previously done via the `OwnerName` parameter in `Set-SqlDscDatabase`.
- Added public command `Test-SqlDscIsDatabase` to test if a database exists on a
  SQL Server Database Engine instance ([issue #2201](https://github.com/dsccommunity/SqlServerDsc/issues/2201)).
- Added public command `Get-SqlDscSetupLog` to retrieve SQL Server setup bootstrap
  logs (Summary.txt) from the most recent setup operation. This command can be used
  interactively for troubleshooting or within integration tests to help diagnose
  setup failures. Integration tests have been updated to use this command instead
  of duplicated error handling code [issue #2311](https://github.com/dsccommunity/SqlServerDsc/issues/2311).
- Added script `Remove-SqlServerFromCIImage.ps1` to remove pre-installed SQL Server
  components from Microsoft Hosted agents that conflict with PrepareImage operations.
  The script is now run automatically in the CI pipeline before PrepareImage tests
  to resolve Sysprep compatibility errors [issue #2212](https://github.com/dsccommunity/SqlServerDsc/issues/2212).
- Added integration tests for `Complete-SqlDscImage` command to ensure command
  reliability in prepared image installation workflows. The test runs in a separate
  pipeline job `Integration_Test_Commands_SqlServer_PreparedImage` with its own CI
  worker, and verifies the completion of SQL Server instances prepared using
  `Install-SqlDscServer` with the `-PrepareImage` parameter. The test includes
  scenarios with minimal parameters and various service account/directory
  configurations [issue #2212](https://github.com/dsccommunity/SqlServerDsc/issues/2212).
- Added integration test for `Install-SqlDscServer` with the `-PrepareImage`
  parameter set to support the prepared image installation workflow. This test
  (`Install-SqlDscServer.Integration.PrepareImage.Tests.ps1`) runs in the
  `Integration_Test_Commands_SqlServer_PreparedImage` pipeline job and prepares
  a DSCSQLTEST instance that is later completed by `Complete-SqlDscImage` tests
  [issue #2212](https://github.com/dsccommunity/SqlServerDsc/issues/2212).
- Added integration tests for `Initialize-SqlDscRebuildDatabase` command to ensure
  command reliability. The test runs in group 8, alongside `Repair-SqlDscServer`,
  to verify the rebuild database functionality on the DSCSQLTEST instance
  [issue #2242](https://github.com/dsccommunity/SqlServerDsc/issues/2242).
- Added integration tests for `Repair-SqlDscServer` command to ensure command
  reliability. The test runs in group 8, before `Uninstall-SqlDscServer` in
  group 9, to verify the repair functionality on the DSCSQLTEST instance
  [issue #2238](https://github.com/dsccommunity/SqlServerDsc/issues/2238).
- Added integration tests for `ConvertTo-SqlDscServerPermission` command to ensure
  command reliability [issue #2207](https://github.com/dsccommunity/SqlServerDsc/issues/2207).
- Added post-installation configuration integration test to configure SSL certificate
  support for SQL Server instance DSCSQLTEST in CI environment, enabling testing
  of encryption-related functionality. The new `PostInstallationConfiguration`
  integration test includes:
  - Self-signed SSL certificate creation and installation
  - Certificate configuration for SQL Server Database Engine
  - Service account permissions for certificate private key access
  - Certificate trust chain configuration
  - Verification that encryption is properly configured
  - Enabled previously skipped encryption tests in `Invoke-SqlDscQuery`
  - Added integration tests for `Connect-SqlDscDatabaseEngine` command to verify
    the `-Encrypt` parameter functionality
  [issue #2290](https://github.com/dsccommunity/SqlServerDsc/issues/2290).
- Added integration tests for `Get-SqlDscDatabasePermission` command to ensure
  database permission retrieval functions correctly in real environments
  [issue #2221](https://github.com/dsccommunity/SqlServerDsc/issues/2221).
- Added integration tests for `Get-SqlDscManagedComputer` command to ensure it
  functions correctly in real environments
  [issue #2220](https://github.com/dsccommunity/SqlServerDsc/issues/2220).
- Added integration tests for `Remove-SqlDscAudit` command to ensure it functions
  correctly in real environments
  [issue #2241](https://github.com/dsccommunity/SqlServerDsc/issues/2241).
- Added integration tests for `ConvertFrom-SqlDscDatabasePermission` command to
  ensure it functions correctly in real environments
  [issue #2211](https://github.com/dsccommunity/SqlServerDsc/issues/2211).
- Added integration tests for `Get-SqlDscStartupParameter` command to ensure it
  functions correctly in real environments
  [issue #2217](https://github.com/dsccommunity/SqlServe'

        } # End of PSData hashtable

    } # End of PrivateData hashtable
}
