# Description

Creates and registers a new session configuration endpoint.
