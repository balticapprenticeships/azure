# Description

This resource installs or uninstalls a package on the host.
