# Description

This resource is used to install, uninstall and query roles or features on
the node.

## Requirements

- Target machine must be running Windows Server 2008 or later.
- Target machine must have access to the DISM PowerShell module.
- Target machine must have access to the ServerManager module.
